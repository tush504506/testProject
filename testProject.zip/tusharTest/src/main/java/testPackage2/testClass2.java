package testPackage2;

public class testClass2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	}

}
